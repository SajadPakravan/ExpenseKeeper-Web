import { Clock3 } from 'lucide-react';
import { persianDigit } from '@/tools/formating';

type TimePickerProps = {
    value: string;
    onChange: (value: string) => void;
};

const HOURS = Array.from({ length: 24 }, (_, index) => index.toString().padStart(2, '0'));

const MINUTES = Array.from({ length: 60 }, (_, index) => index.toString().padStart(2, '0'));

export default function TimePicker({ value, onChange }: TimePickerProps) {
    const [hour = '', minute = ''] = value ? value.split(':') : [];

    function setHour(newHour: string) {
        onChange(`${newHour}:${minute || '00'}`);
    }

    function setMinute(newMinute: string) {
        onChange(`${hour || '00'}:${newMinute}`);
    }

    return (
        <div>
            <div className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white p-2 dark:border-white/10 dark:bg-white/[0.04]">
                {/* ساعت */}
                <select
                    value={hour}
                    onChange={(event) => setHour(event.target.value)}
                    className="h-11 flex-1 rounded-lg bg-transparent text-center text-slate-900 outline-none dark:text-white"
                >
                    <option value="">ساعت</option>

                    {HOURS.map((item) => (
                        <option key={item} value={item} className="dark:bg-slate-900">
                            {persianDigit(item)}
                        </option>
                    ))}
                </select>

                <span className="text-lg font-bold text-slate-400">:</span>

                {/* دقیقه */}
                <select
                    value={minute}
                    onChange={(event) => setMinute(event.target.value)}
                    className="h-11 flex-1 rounded-lg bg-transparent text-center text-slate-900 outline-none dark:text-white"
                >
                    <option value="">دقیقه</option>

                    {MINUTES.map((item) => (
                        <option key={item} value={item} className="dark:bg-slate-900">
                            {persianDigit(item)}
                        </option>
                    ))}
                </select>
            </div>
        </div>
    );
}

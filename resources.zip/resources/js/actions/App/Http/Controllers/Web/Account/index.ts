import DashboardController from './DashboardController'
import ProfileController from './ProfileController'
import IncomeController from './IncomeController'
import ExpenseController from './ExpenseController'
const Account = {
    DashboardController: Object.assign(DashboardController, DashboardController),
ProfileController: Object.assign(ProfileController, ProfileController),
IncomeController: Object.assign(IncomeController, IncomeController),
ExpenseController: Object.assign(ExpenseController, ExpenseController),
}

export default Account
export default function CreateIncomeForm(){
    return (
        <form>
            <div>
                <label>عنوان درآمد</label>

                <input
                    type="text"

                    className="w-full rounded-lg border p-2"
                />
            </div>

            <div>
                <label>مبلغ</label>

                <input
                    type="number"
                    className="w-full rounded-lg border p-2"
                />
            </div>

            <div>
                <label>نوع درآمد</label>

                <>
            </div>


            <div>
                <label>زمان</label>

                <>
            </div>

            <div className="mt-5 flex gap-3">
                <button
                    type="submit"
                    className="rounded-lg bg-emerald-600 px-5 py-2 text-white"
                >
                    ذخیره
                </button>
            </div>
        </form>
    );
}

import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\PanelPageController::section
 * @see app/Http/Controllers/PanelPageController.php:21
 * @route '/account/{section}'
 */
export const section = (args: { section: string | number } | [section: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: section.url(args, options),
    method: 'get',
})

section.definition = {
    methods: ["get","head"],
    url: '/account/{section}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PanelPageController::section
 * @see app/Http/Controllers/PanelPageController.php:21
 * @route '/account/{section}'
 */
section.url = (args: { section: string | number } | [section: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { section: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    section: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        section: args.section,
                }

    return section.definition.url
            .replace('{section}', parsedArgs.section.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PanelPageController::section
 * @see app/Http/Controllers/PanelPageController.php:21
 * @route '/account/{section}'
 */
section.get = (args: { section: string | number } | [section: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: section.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PanelPageController::section
 * @see app/Http/Controllers/PanelPageController.php:21
 * @route '/account/{section}'
 */
section.head = (args: { section: string | number } | [section: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: section.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PanelPageController::section
 * @see app/Http/Controllers/PanelPageController.php:21
 * @route '/account/{section}'
 */
    const sectionForm = (args: { section: string | number } | [section: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: section.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PanelPageController::section
 * @see app/Http/Controllers/PanelPageController.php:21
 * @route '/account/{section}'
 */
        sectionForm.get = (args: { section: string | number } | [section: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: section.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PanelPageController::section
 * @see app/Http/Controllers/PanelPageController.php:21
 * @route '/account/{section}'
 */
        sectionForm.head = (args: { section: string | number } | [section: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: section.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    section.form = sectionForm
const account = {
    section: Object.assign(section, section),
}

export default account
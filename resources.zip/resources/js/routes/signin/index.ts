import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Web\Authentication\AuthenticationController::show
 * @see app/Http/Controllers/Web/Authentication/AuthenticationController.php:24
 * @route '/sign-in'
 */
export const show = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/sign-in',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Authentication\AuthenticationController::show
 * @see app/Http/Controllers/Web/Authentication/AuthenticationController.php:24
 * @route '/sign-in'
 */
show.url = (options?: RouteQueryOptions) => {
    return show.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Authentication\AuthenticationController::show
 * @see app/Http/Controllers/Web/Authentication/AuthenticationController.php:24
 * @route '/sign-in'
 */
show.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Authentication\AuthenticationController::show
 * @see app/Http/Controllers/Web/Authentication/AuthenticationController.php:24
 * @route '/sign-in'
 */
show.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Authentication\AuthenticationController::show
 * @see app/Http/Controllers/Web/Authentication/AuthenticationController.php:24
 * @route '/sign-in'
 */
    const showForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Authentication\AuthenticationController::show
 * @see app/Http/Controllers/Web/Authentication/AuthenticationController.php:24
 * @route '/sign-in'
 */
        showForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Authentication\AuthenticationController::show
 * @see app/Http/Controllers/Web/Authentication/AuthenticationController.php:24
 * @route '/sign-in'
 */
        showForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
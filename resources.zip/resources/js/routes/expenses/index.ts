import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Web\Account\ExpenseController::create
 * @see app/Http/Controllers/Web/Account/ExpenseController.php:16
 * @route '/account/expenses'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: create.url(options),
    method: 'post',
})

create.definition = {
    methods: ["post"],
    url: '/account/expenses',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Account\ExpenseController::create
 * @see app/Http/Controllers/Web/Account/ExpenseController.php:16
 * @route '/account/expenses'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Account\ExpenseController::create
 * @see app/Http/Controllers/Web/Account/ExpenseController.php:16
 * @route '/account/expenses'
 */
create.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: create.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Account\ExpenseController::create
 * @see app/Http/Controllers/Web/Account/ExpenseController.php:16
 * @route '/account/expenses'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: create.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Account\ExpenseController::create
 * @see app/Http/Controllers/Web/Account/ExpenseController.php:16
 * @route '/account/expenses'
 */
        createForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: create.url(options),
            method: 'post',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Web\Account\ExpenseController::update
 * @see app/Http/Controllers/Web/Account/ExpenseController.php:21
 * @route '/account/expenses/{id}'
 */
export const update = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/account/expenses/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Web\Account\ExpenseController::update
 * @see app/Http/Controllers/Web/Account/ExpenseController.php:21
 * @route '/account/expenses/{id}'
 */
update.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return update.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Account\ExpenseController::update
 * @see app/Http/Controllers/Web/Account/ExpenseController.php:21
 * @route '/account/expenses/{id}'
 */
update.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Web\Account\ExpenseController::update
 * @see app/Http/Controllers/Web/Account/ExpenseController.php:21
 * @route '/account/expenses/{id}'
 */
    const updateForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Account\ExpenseController::update
 * @see app/Http/Controllers/Web/Account/ExpenseController.php:21
 * @route '/account/expenses/{id}'
 */
        updateForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const expenses = {
    create: Object.assign(create, create),
update: Object.assign(update, update),
}

export default expenses
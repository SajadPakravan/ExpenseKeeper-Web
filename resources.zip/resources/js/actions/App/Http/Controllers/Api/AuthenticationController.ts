import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Api\AuthenticationController::signUp
 * @see app/Http/Controllers/Api/AuthenticationController.php:20
 * @route '/api/v1/auth/signup'
 */
export const signUp = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: signUp.url(options),
    method: 'post',
})

signUp.definition = {
    methods: ["post"],
    url: '/api/v1/auth/signup',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AuthenticationController::signUp
 * @see app/Http/Controllers/Api/AuthenticationController.php:20
 * @route '/api/v1/auth/signup'
 */
signUp.url = (options?: RouteQueryOptions) => {
    return signUp.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthenticationController::signUp
 * @see app/Http/Controllers/Api/AuthenticationController.php:20
 * @route '/api/v1/auth/signup'
 */
signUp.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: signUp.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\AuthenticationController::signUp
 * @see app/Http/Controllers/Api/AuthenticationController.php:20
 * @route '/api/v1/auth/signup'
 */
    const signUpForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: signUp.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\AuthenticationController::signUp
 * @see app/Http/Controllers/Api/AuthenticationController.php:20
 * @route '/api/v1/auth/signup'
 */
        signUpForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: signUp.url(options),
            method: 'post',
        })
    
    signUp.form = signUpForm
/**
* @see \App\Http\Controllers\Api\AuthenticationController::signIn
 * @see app/Http/Controllers/Api/AuthenticationController.php:39
 * @route '/api/v1/auth/signin'
 */
export const signIn = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: signIn.url(options),
    method: 'post',
})

signIn.definition = {
    methods: ["post"],
    url: '/api/v1/auth/signin',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AuthenticationController::signIn
 * @see app/Http/Controllers/Api/AuthenticationController.php:39
 * @route '/api/v1/auth/signin'
 */
signIn.url = (options?: RouteQueryOptions) => {
    return signIn.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthenticationController::signIn
 * @see app/Http/Controllers/Api/AuthenticationController.php:39
 * @route '/api/v1/auth/signin'
 */
signIn.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: signIn.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\AuthenticationController::signIn
 * @see app/Http/Controllers/Api/AuthenticationController.php:39
 * @route '/api/v1/auth/signin'
 */
    const signInForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: signIn.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\AuthenticationController::signIn
 * @see app/Http/Controllers/Api/AuthenticationController.php:39
 * @route '/api/v1/auth/signin'
 */
        signInForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: signIn.url(options),
            method: 'post',
        })
    
    signIn.form = signInForm
/**
* @see \App\Http\Controllers\Api\AuthenticationController::logout
 * @see app/Http/Controllers/Api/AuthenticationController.php:71
 * @route '/api/v1/auth/logout'
 */
export const logout = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

logout.definition = {
    methods: ["post"],
    url: '/api/v1/auth/logout',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Api\AuthenticationController::logout
 * @see app/Http/Controllers/Api/AuthenticationController.php:71
 * @route '/api/v1/auth/logout'
 */
logout.url = (options?: RouteQueryOptions) => {
    return logout.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthenticationController::logout
 * @see app/Http/Controllers/Api/AuthenticationController.php:71
 * @route '/api/v1/auth/logout'
 */
logout.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: logout.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Api\AuthenticationController::logout
 * @see app/Http/Controllers/Api/AuthenticationController.php:71
 * @route '/api/v1/auth/logout'
 */
    const logoutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: logout.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Api\AuthenticationController::logout
 * @see app/Http/Controllers/Api/AuthenticationController.php:71
 * @route '/api/v1/auth/logout'
 */
        logoutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: logout.url(options),
            method: 'post',
        })
    
    logout.form = logoutForm
/**
* @see \App\Http\Controllers\Api\AuthenticationController::me
 * @see app/Http/Controllers/Api/AuthenticationController.php:64
 * @route '/api/v1/user'
 */
export const me = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: me.url(options),
    method: 'get',
})

me.definition = {
    methods: ["get","head"],
    url: '/api/v1/user',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Api\AuthenticationController::me
 * @see app/Http/Controllers/Api/AuthenticationController.php:64
 * @route '/api/v1/user'
 */
me.url = (options?: RouteQueryOptions) => {
    return me.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Api\AuthenticationController::me
 * @see app/Http/Controllers/Api/AuthenticationController.php:64
 * @route '/api/v1/user'
 */
me.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: me.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Api\AuthenticationController::me
 * @see app/Http/Controllers/Api/AuthenticationController.php:64
 * @route '/api/v1/user'
 */
me.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: me.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Api\AuthenticationController::me
 * @see app/Http/Controllers/Api/AuthenticationController.php:64
 * @route '/api/v1/user'
 */
    const meForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: me.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Api\AuthenticationController::me
 * @see app/Http/Controllers/Api/AuthenticationController.php:64
 * @route '/api/v1/user'
 */
        meForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: me.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Api\AuthenticationController::me
 * @see app/Http/Controllers/Api/AuthenticationController.php:64
 * @route '/api/v1/user'
 */
        meForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: me.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    me.form = meForm
const AuthenticationController = { signUp, signIn, logout, me }

export default AuthenticationController
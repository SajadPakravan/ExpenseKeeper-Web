export default function AddIncome() {

}

import Api from './Api'
import HomeController from './HomeController'
import Web from './Web'
import PanelPageController from './PanelPageController'
const Controllers = {
    Api: Object.assign(Api, Api),
HomeController: Object.assign(HomeController, HomeController),
Web: Object.assign(Web, Web),
PanelPageController: Object.assign(PanelPageController, PanelPageController),
}

export default Controllers
import {XCircle} from "lucide-react";
import type { ReactNode} from 'react';
import { useEffect } from 'react';

interface ModalProps {
    open: boolean;
    onClose: () => void;
    children: ReactNode;
}

export default function Modal({ open, onClose, children }: ModalProps) {
    useEffect(() => {
        if (open) {
            document.body.style.overflow = 'hidden';
        }

        return () => {
            document.body.style.overflow = 'auto';
        };
    }, [open]);

    if (!open) {
        return null;
    }

    return (
        <div className="animate-fadeIn fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
            <div className="animate-slideUp w-full max-w-xl rounded-2xl bg-white p-6 shadow-xl dark:bg-slate-900">
                <XCircle type="button" onClick={onClose} className="cursor-pointer"/>
                {children}
            </div>
        </div>
    );
}

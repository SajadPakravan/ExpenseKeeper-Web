import type { ReactNode, RefObject } from 'react';
import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';

type FloatingPopoverProps = {
    open: boolean;
    anchorRef: RefObject<HTMLElement | null>;
    children: ReactNode;
    onClose: () => void;
};

type Position = {
    left: number;
    width: number;
    top?: number;
    bottom?: number;
    maxHeight: number;
};

export default function FloatingPopover({ open, anchorRef, children, onClose }: FloatingPopoverProps) {
    const popoverRef = useRef<HTMLDivElement>(null);
    const [position, setPosition] = useState<Position | null>(null);

    function updatePosition() {
        const anchor = anchorRef.current;

        if (!anchor) {
            return;
        }

        const rect = anchor.getBoundingClientRect();
        const gap = 8;
        const viewportPadding = 12;
        const availableBelow = window.innerHeight - rect.bottom - viewportPadding;
        const availableAbove = rect.top - viewportPadding;
        const preferAbove = availableBelow < 220 && availableAbove > availableBelow;
        const maxHeight = Math.min(320, preferAbove ? availableAbove - gap : availableBelow - gap);

        if (preferAbove) {
            setPosition({
                left: rect.left,
                width: rect.width,
                bottom: window.innerHeight - rect.top + gap,
                maxHeight,
            });

            return;
        }

        setPosition({
            left: rect.left,
            width: rect.width,
            top: rect.bottom + gap,
            maxHeight,
        });
    }

    useLayoutEffect(() => {
        if (!open) {
            return;
        }

        updatePosition();

        window.addEventListener('resize', updatePosition);
        window.addEventListener('scroll', updatePosition, true);

        return () => {
            window.removeEventListener('resize', updatePosition);
            window.removeEventListener('scroll', updatePosition, true);
        };
    }, [open, updatePosition]);

    useEffect(() => {
        if (!open) {
            return;
        }

        function handlePointerDown(event: PointerEvent) {
            const target = event.target as Node;

            if (anchorRef.current?.contains(target)) {
                return;
            }

            if (popoverRef.current?.contains(target)) {
                return;
            }

            onClose();
        }

        document.addEventListener('pointerdown', handlePointerDown);

        return () => {
            document.removeEventListener('pointerdown', handlePointerDown);
        };
    }, [open, anchorRef, onClose]);

    if (!open || !position || typeof document === 'undefined') {
        return null;
    }

    return createPortal(
        <div
            ref={popoverRef}
            dir="rtl"
            style={{
                position: 'fixed',
                left: position.left,
                width: position.width,
                top: position.top,
                bottom: position.bottom,
                maxHeight: position.maxHeight,
            }}
            className="z-[9999] overflow-y-auto rounded-2xl border border-slate-200 bg-white p-2 shadow-2xl shadow-slate-950/20 dark:border-white/10 dark:bg-slate-900 dark:shadow-black/50"
        >
            {children}
        </div>,
        document.body,
    );
}

import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Web\Authentication\AuthenticationController::store
 * @see app/Http/Controllers/Web/Authentication/AuthenticationController.php:34
 * @route '/sign-up'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/sign-up',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Authentication\AuthenticationController::store
 * @see app/Http/Controllers/Web/Authentication/AuthenticationController.php:34
 * @route '/sign-up'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Authentication\AuthenticationController::store
 * @see app/Http/Controllers/Web/Authentication/AuthenticationController.php:34
 * @route '/sign-up'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Authentication\AuthenticationController::store
 * @see app/Http/Controllers/Web/Authentication/AuthenticationController.php:34
 * @route '/sign-up'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Authentication\AuthenticationController::store
 * @see app/Http/Controllers/Web/Authentication/AuthenticationController.php:34
 * @route '/sign-up'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
const signup = {
    store: Object.assign(store, store),
}

export default signup
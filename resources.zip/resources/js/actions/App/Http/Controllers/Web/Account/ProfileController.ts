import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Web\Account\ProfileController::index
 * @see app/Http/Controllers/Web/Account/ProfileController.php:22
 * @route '/account/profile'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/account/profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Account\ProfileController::index
 * @see app/Http/Controllers/Web/Account/ProfileController.php:22
 * @route '/account/profile'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Account\ProfileController::index
 * @see app/Http/Controllers/Web/Account/ProfileController.php:22
 * @route '/account/profile'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Account\ProfileController::index
 * @see app/Http/Controllers/Web/Account/ProfileController.php:22
 * @route '/account/profile'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Account\ProfileController::index
 * @see app/Http/Controllers/Web/Account/ProfileController.php:22
 * @route '/account/profile'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Account\ProfileController::index
 * @see app/Http/Controllers/Web/Account/ProfileController.php:22
 * @route '/account/profile'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Account\ProfileController::index
 * @see app/Http/Controllers/Web/Account/ProfileController.php:22
 * @route '/account/profile'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Web\Account\ProfileController::update
 * @see app/Http/Controllers/Web/Account/ProfileController.php:27
 * @route '/account/profile'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/account/profile',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Account\ProfileController::update
 * @see app/Http/Controllers/Web/Account/ProfileController.php:27
 * @route '/account/profile'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Account\ProfileController::update
 * @see app/Http/Controllers/Web/Account/ProfileController.php:27
 * @route '/account/profile'
 */
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Account\ProfileController::update
 * @see app/Http/Controllers/Web/Account/ProfileController.php:27
 * @route '/account/profile'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Account\ProfileController::update
 * @see app/Http/Controllers/Web/Account/ProfileController.php:27
 * @route '/account/profile'
 */
        updateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(options),
            method: 'post',
        })
    
    update.form = updateForm
const ProfileController = { index, update }

export default ProfileController
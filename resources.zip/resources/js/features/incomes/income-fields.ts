import { } from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import type { IncomeFieldName } from './types';

export type IncomeFieldDefinition = {
    name: IncomeFieldName;
    label: string;
    placeholder: string;
    icon: LucideIcon;
    dir?: 'rtl' | 'ltr';
};

export const PROFILE_FIELDS: readonly IncomeFieldDefinition[] = [
    {
        name: 'title',
        label: 'عنوان درآمد',
        placeholder: 'مثلا حقوق کارمندی',
        icon: ,
    },
    {
        name: 'amount',
        label: 'مبلغ درآمد',
        placeholder: 'مثلا ۳۰،۰۰۰،۰۰۰',
        icon: ,
        dir: 'ltr',
    },
    {
        name: 'type',
        label: 'نوع درآمد',
        placeholder: 'دائمی یا موقت',
        icon: ,
    },
    {
        name: 'permanent_type',
        label: 'نوع درآمد دائمی',
        placeholder: 'بصورت روزانه، هفتگی، ماهانه یا سالیانه ',
        icon: ,
    },
];

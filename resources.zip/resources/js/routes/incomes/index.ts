import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Web\Account\IncomeController::create
 * @see app/Http/Controllers/Web/Account/IncomeController.php:19
 * @route '/account/incomes'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: create.url(options),
    method: 'post',
})

create.definition = {
    methods: ["post"],
    url: '/account/incomes',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Account\IncomeController::create
 * @see app/Http/Controllers/Web/Account/IncomeController.php:19
 * @route '/account/incomes'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Account\IncomeController::create
 * @see app/Http/Controllers/Web/Account/IncomeController.php:19
 * @route '/account/incomes'
 */
create.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: create.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Account\IncomeController::create
 * @see app/Http/Controllers/Web/Account/IncomeController.php:19
 * @route '/account/incomes'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: create.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Account\IncomeController::create
 * @see app/Http/Controllers/Web/Account/IncomeController.php:19
 * @route '/account/incomes'
 */
        createForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: create.url(options),
            method: 'post',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Web\Account\IncomeController::update
 * @see app/Http/Controllers/Web/Account/IncomeController.php:24
 * @route '/account/incomes/{id}'
 */
export const update = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/account/incomes/{id}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\Web\Account\IncomeController::update
 * @see app/Http/Controllers/Web/Account/IncomeController.php:24
 * @route '/account/incomes/{id}'
 */
update.url = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { id: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    id: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        id: args.id,
                }

    return update.definition.url
            .replace('{id}', parsedArgs.id.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Account\IncomeController::update
 * @see app/Http/Controllers/Web/Account/IncomeController.php:24
 * @route '/account/incomes/{id}'
 */
update.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\Web\Account\IncomeController::update
 * @see app/Http/Controllers/Web/Account/IncomeController.php:24
 * @route '/account/incomes/{id}'
 */
    const updateForm = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Account\IncomeController::update
 * @see app/Http/Controllers/Web/Account/IncomeController.php:24
 * @route '/account/incomes/{id}'
 */
        updateForm.put = (args: { id: string | number } | [id: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
const incomes = {
    create: Object.assign(create, create),
update: Object.assign(update, update),
}

export default incomes
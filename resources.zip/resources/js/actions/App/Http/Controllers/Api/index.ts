import AuthenticationController from './AuthenticationController'
const Api = {
    AuthenticationController: Object.assign(AuthenticationController, AuthenticationController),
}

export default Api
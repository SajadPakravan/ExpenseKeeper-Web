import Authentication from './Authentication'
import Account from './Account'
const Web = {
    Authentication: Object.assign(Authentication, Authentication),
Account: Object.assign(Account, Account),
}

export default Web
import { usePage } from '@inertiajs/react';
import {useState} from "react";
import Modal from '@/components/modal';
import CreateIncomeForm from '@/features/incomes/components/create-income-form';
import IncomeTable from '@/features/incomes/components/income-table';
import type { Income } from '@/features/incomes/types';
import AccountLayout from '@/layouts/account-layout';

type Props = { incomes: Income[]; };

export default function Incomes() {
    const { incomes } = usePage<Props>().props;
    const [open, setOpen] = useState(false);

    return (
        <AccountLayout title="درآمدها">
            <div className="space-y-6">
                <button
                    onClick={() => setOpen(true)}
                    className="cursor-pointer rounded-xl bg-emerald-600 px-5 py-3 text-white"
                >
                    افزودن درآمد
                </button>

                <IncomeTable incomes={incomes} />
            </div>

            <Modal open={open} onClose={() => setOpen(false)}>
                <CreateIncomeForm />
            </Modal>
        </AccountLayout>
    );
}

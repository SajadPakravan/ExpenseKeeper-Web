import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../wayfinder'
/**
* @see \App\Http\Controllers\HomeController::home
 * @see app/Http/Controllers/HomeController.php:10
 * @route '/'
 */
export const home = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})

home.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\HomeController::home
 * @see app/Http/Controllers/HomeController.php:10
 * @route '/'
 */
home.url = (options?: RouteQueryOptions) => {
    return home.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\HomeController::home
 * @see app/Http/Controllers/HomeController.php:10
 * @route '/'
 */
home.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\HomeController::home
 * @see app/Http/Controllers/HomeController.php:10
 * @route '/'
 */
home.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: home.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\HomeController::home
 * @see app/Http/Controllers/HomeController.php:10
 * @route '/'
 */
    const homeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: home.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\HomeController::home
 * @see app/Http/Controllers/HomeController.php:10
 * @route '/'
 */
        homeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\HomeController::home
 * @see app/Http/Controllers/HomeController.php:10
 * @route '/'
 */
        homeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    home.form = homeForm
/**
* @see \App\Http\Controllers\Web\Authentication\AuthenticationController::signIn
 * @see app/Http/Controllers/Web/Authentication/AuthenticationController.php:51
 * @route '/sign-in'
 */
export const signIn = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: signIn.url(options),
    method: 'post',
})

signIn.definition = {
    methods: ["post"],
    url: '/sign-in',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Authentication\AuthenticationController::signIn
 * @see app/Http/Controllers/Web/Authentication/AuthenticationController.php:51
 * @route '/sign-in'
 */
signIn.url = (options?: RouteQueryOptions) => {
    return signIn.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Authentication\AuthenticationController::signIn
 * @see app/Http/Controllers/Web/Authentication/AuthenticationController.php:51
 * @route '/sign-in'
 */
signIn.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: signIn.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Authentication\AuthenticationController::signIn
 * @see app/Http/Controllers/Web/Authentication/AuthenticationController.php:51
 * @route '/sign-in'
 */
    const signInForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: signIn.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Authentication\AuthenticationController::signIn
 * @see app/Http/Controllers/Web/Authentication/AuthenticationController.php:51
 * @route '/sign-in'
 */
        signInForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: signIn.url(options),
            method: 'post',
        })
    
    signIn.form = signInForm
/**
* @see \App\Http\Controllers\Web\Authentication\AuthenticationController::signOut
 * @see app/Http/Controllers/Web/Authentication/AuthenticationController.php:72
 * @route '/sign-out'
 */
export const signOut = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: signOut.url(options),
    method: 'post',
})

signOut.definition = {
    methods: ["post"],
    url: '/sign-out',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Web\Authentication\AuthenticationController::signOut
 * @see app/Http/Controllers/Web/Authentication/AuthenticationController.php:72
 * @route '/sign-out'
 */
signOut.url = (options?: RouteQueryOptions) => {
    return signOut.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Authentication\AuthenticationController::signOut
 * @see app/Http/Controllers/Web/Authentication/AuthenticationController.php:72
 * @route '/sign-out'
 */
signOut.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: signOut.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Web\Authentication\AuthenticationController::signOut
 * @see app/Http/Controllers/Web/Authentication/AuthenticationController.php:72
 * @route '/sign-out'
 */
    const signOutForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: signOut.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Web\Authentication\AuthenticationController::signOut
 * @see app/Http/Controllers/Web/Authentication/AuthenticationController.php:72
 * @route '/sign-out'
 */
        signOutForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: signOut.url(options),
            method: 'post',
        })
    
    signOut.form = signOutForm
/**
* @see \App\Http\Controllers\Web\Account\DashboardController::dashboard
 * @see app/Http/Controllers/Web/Account/DashboardController.php:11
 * @route '/account/dashboard'
 */
export const dashboard = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})

dashboard.definition = {
    methods: ["get","head"],
    url: '/account/dashboard',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Account\DashboardController::dashboard
 * @see app/Http/Controllers/Web/Account/DashboardController.php:11
 * @route '/account/dashboard'
 */
dashboard.url = (options?: RouteQueryOptions) => {
    return dashboard.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Account\DashboardController::dashboard
 * @see app/Http/Controllers/Web/Account/DashboardController.php:11
 * @route '/account/dashboard'
 */
dashboard.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: dashboard.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Account\DashboardController::dashboard
 * @see app/Http/Controllers/Web/Account/DashboardController.php:11
 * @route '/account/dashboard'
 */
dashboard.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: dashboard.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Account\DashboardController::dashboard
 * @see app/Http/Controllers/Web/Account/DashboardController.php:11
 * @route '/account/dashboard'
 */
    const dashboardForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: dashboard.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Account\DashboardController::dashboard
 * @see app/Http/Controllers/Web/Account/DashboardController.php:11
 * @route '/account/dashboard'
 */
        dashboardForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Account\DashboardController::dashboard
 * @see app/Http/Controllers/Web/Account/DashboardController.php:11
 * @route '/account/dashboard'
 */
        dashboardForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: dashboard.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    dashboard.form = dashboardForm
/**
* @see \App\Http\Controllers\Web\Account\ProfileController::profile
 * @see app/Http/Controllers/Web/Account/ProfileController.php:22
 * @route '/account/profile'
 */
export const profile = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profile.url(options),
    method: 'get',
})

profile.definition = {
    methods: ["get","head"],
    url: '/account/profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Account\ProfileController::profile
 * @see app/Http/Controllers/Web/Account/ProfileController.php:22
 * @route '/account/profile'
 */
profile.url = (options?: RouteQueryOptions) => {
    return profile.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Account\ProfileController::profile
 * @see app/Http/Controllers/Web/Account/ProfileController.php:22
 * @route '/account/profile'
 */
profile.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profile.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Account\ProfileController::profile
 * @see app/Http/Controllers/Web/Account/ProfileController.php:22
 * @route '/account/profile'
 */
profile.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: profile.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Account\ProfileController::profile
 * @see app/Http/Controllers/Web/Account/ProfileController.php:22
 * @route '/account/profile'
 */
    const profileForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: profile.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Account\ProfileController::profile
 * @see app/Http/Controllers/Web/Account/ProfileController.php:22
 * @route '/account/profile'
 */
        profileForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: profile.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Account\ProfileController::profile
 * @see app/Http/Controllers/Web/Account/ProfileController.php:22
 * @route '/account/profile'
 */
        profileForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: profile.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    profile.form = profileForm
/**
* @see \App\Http\Controllers\Web\Account\IncomeController::incomes
 * @see app/Http/Controllers/Web/Account/IncomeController.php:11
 * @route '/account/incomes'
 */
export const incomes = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: incomes.url(options),
    method: 'get',
})

incomes.definition = {
    methods: ["get","head"],
    url: '/account/incomes',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Account\IncomeController::incomes
 * @see app/Http/Controllers/Web/Account/IncomeController.php:11
 * @route '/account/incomes'
 */
incomes.url = (options?: RouteQueryOptions) => {
    return incomes.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Account\IncomeController::incomes
 * @see app/Http/Controllers/Web/Account/IncomeController.php:11
 * @route '/account/incomes'
 */
incomes.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: incomes.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Account\IncomeController::incomes
 * @see app/Http/Controllers/Web/Account/IncomeController.php:11
 * @route '/account/incomes'
 */
incomes.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: incomes.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Account\IncomeController::incomes
 * @see app/Http/Controllers/Web/Account/IncomeController.php:11
 * @route '/account/incomes'
 */
    const incomesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: incomes.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Account\IncomeController::incomes
 * @see app/Http/Controllers/Web/Account/IncomeController.php:11
 * @route '/account/incomes'
 */
        incomesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: incomes.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Account\IncomeController::incomes
 * @see app/Http/Controllers/Web/Account/IncomeController.php:11
 * @route '/account/incomes'
 */
        incomesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: incomes.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    incomes.form = incomesForm
/**
* @see \App\Http\Controllers\Web\Account\ExpenseController::expenses
 * @see app/Http/Controllers/Web/Account/ExpenseController.php:11
 * @route '/account/expenses'
 */
export const expenses = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: expenses.url(options),
    method: 'get',
})

expenses.definition = {
    methods: ["get","head"],
    url: '/account/expenses',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Web\Account\ExpenseController::expenses
 * @see app/Http/Controllers/Web/Account/ExpenseController.php:11
 * @route '/account/expenses'
 */
expenses.url = (options?: RouteQueryOptions) => {
    return expenses.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Web\Account\ExpenseController::expenses
 * @see app/Http/Controllers/Web/Account/ExpenseController.php:11
 * @route '/account/expenses'
 */
expenses.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: expenses.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Web\Account\ExpenseController::expenses
 * @see app/Http/Controllers/Web/Account/ExpenseController.php:11
 * @route '/account/expenses'
 */
expenses.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: expenses.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Web\Account\ExpenseController::expenses
 * @see app/Http/Controllers/Web/Account/ExpenseController.php:11
 * @route '/account/expenses'
 */
    const expensesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: expenses.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Web\Account\ExpenseController::expenses
 * @see app/Http/Controllers/Web/Account/ExpenseController.php:11
 * @route '/account/expenses'
 */
        expensesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: expenses.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Web\Account\ExpenseController::expenses
 * @see app/Http/Controllers/Web/Account/ExpenseController.php:11
 * @route '/account/expenses'
 */
        expensesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: expenses.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    expenses.form = expensesForm